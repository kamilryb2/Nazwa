package pakiet1;
import pakiet1.Gra;


public class Gra {
    public void pokazNaEkranie(){
        Pojazd pojazd = new Pojazd();
        System.out.println(pojazd.name);
        System.out.println(pojazd.iloscKol);
        System.out.println(pojazd.elektryczny);
        System.out.println(pojazd.marka);
    }
    }

