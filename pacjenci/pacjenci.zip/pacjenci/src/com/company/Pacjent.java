package com.company;

public class Pacjent {
    String name;
    String lastName;

    public Pacjent(String name, String lastName) {
        this.name = name;
        this.lastName = lastName;
    }



        class Nerka{
        int ilosc = 2;
    }
      class Watroba{
    boolean czyJestZdrowa = true;}
}
