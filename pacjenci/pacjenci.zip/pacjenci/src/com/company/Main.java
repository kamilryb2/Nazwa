package com.company;

public class Main {

    public static void main(String[] args) {
	Pacjent pacjent = new Pacjent("Irena","Kowalówka");
    Pacjent.Nerka nerka = pacjent.new Nerka();
    

    }
}
