package com.company;

public class Main {

    public static void main(String[] args) {
	int liczba = 6;
	liczba = liczba <<4;
	liczba = liczba >>2;
	liczba = liczba <<7;
	liczba = liczba <<2;
	liczba = liczba >>10;
        System.out.println(liczba);
    }


}
