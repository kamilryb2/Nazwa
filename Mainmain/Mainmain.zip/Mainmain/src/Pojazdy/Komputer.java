package Pojazdy;

public class Komputer {

    String name;
    String color;
    Boolean small;

    void turnOn(){
        System.out.println("Komputer sie uruchomil");
    }
    void turnOff(){
        System.out.println("Komputer się wyłączył");
    }








}
