package Pojazdy;

public class Auto {
}
