package Komputery;

public class Smartfon {
}
