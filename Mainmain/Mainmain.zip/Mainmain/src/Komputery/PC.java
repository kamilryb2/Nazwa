package Komputery;

import Pojazdy.Komputer;

public class PC extends Komputer {
}
