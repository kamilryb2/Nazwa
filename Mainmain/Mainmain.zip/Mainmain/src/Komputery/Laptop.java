package Komputery;

public class Laptop  {
}
