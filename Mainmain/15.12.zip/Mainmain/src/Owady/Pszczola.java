package Owady;

public class Pszczola {
}
