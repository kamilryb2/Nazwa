package Komputery;

public class Smartwatch extends Komputer {
    public Smartwatch(String name, String color, Boolean small) {
        super(name, color, small);
    }
}
