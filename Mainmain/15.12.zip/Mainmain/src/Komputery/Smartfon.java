package Komputery;

public class Smartfon extends Komputer {
    public Smartfon(String name, String color, Boolean small) {
        super(name, color, small);
    }
}
