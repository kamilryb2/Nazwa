package Komputery;

public class PC extends Komputer {


    public PC(String name, String color, Boolean small) {
        super(name, color, small);
    }

}
