package com.company;

public class TrojmianKwadratowy {
    double a;
    double b;
    double c;
    double delta;
    double obliczDelte(double a,double b,double c){

        return delta=b*b-4*a*c;

    }
}
