package com.company;

public class Square {
    Square(){
        System.out.println("Jestem konstruktorem bez parametrów, klasy Square");
    }

    double bok;
    Square(double boczek){
        bok= boczek;
    }


}
