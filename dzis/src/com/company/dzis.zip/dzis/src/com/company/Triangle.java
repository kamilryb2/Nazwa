package com.company;

public class Triangle {
    int sideA;
    int sideB;
    int sideC;

    int obwodTrojkata(int sideA, int sideB, int sideC){
        return sideA + sideB +sideC;

    }
}
