public class Duck {
    String nazwa;

    public Duck(String nazwa) {
        this.nazwa = nazwa;

    }
     void jakLatam(){
        System.out.println("I am flying like duck");
    }

}

